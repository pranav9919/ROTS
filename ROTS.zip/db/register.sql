-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2023 at 08:01 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Table structure for table `farmers`
--

CREATE TABLE `farmers` (
  `id` int(50) UNSIGNED NOT NULL,
  `Company_Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `farmers`
--

INSERT INTO `farmers` (`id`, `Company_Name`, `Email`, `Password`) VALUES
(1, 'hfhhf', 'gggege@gmail.com', '$2y$10$SZJcp0fnno5boiSqLe/.NepzlYYfbBTDpvrYM2vuCVT'),
(2, 'Boss Nation', 'pfpppf@gmail.com', '$2y$10$6ck6yJ4AHe9BKT4F5FbhluQGkR934Lj/Zb636GxqWou'),
(3, 'OgaAde', 'bossnation@gmail.com', '$2y$10$560cP0tumnVxfd2kdCIVGOUR5vemDn9h.Zs7t6nGHef'),
(4, 'My Farms Ltd', 'myfarms@gmail.com', '$2y$10$qrEx9sfOmQRFCuINCrc9r.ssN/layyjg6fo9hOq2Etp'),
(5, 'My Farms Ltd', 'myfarms@gmail.com', '$2y$10$e4jOZzPdYm2ICsS26lPyq.3z8CpkNPx7rTJoCZ9R7A8'),
(6, 'Baba Nla', 'babanla@gmail.com', 'PASSWORD'),
(7, 'Original', 'babanla@gmail.com', 'BOSSNATION'),
(8, 'Ayodeji Farms', 'ayodejifarms@gmail.com', 'ayodeji'),
(9, 'Obasanjo Farms', 'Obasanjo@yahoo.com', 'obasanjo'),
(10, 'Benson Farms', 'Benson@gmail.com', 'benson'),
(11, 'Danladi Farms', 'Danladi Farms', 'danladi'),
(12, 'Fresh Foods', 'freshfoods@gmail.com', 'freshfood'),
(13, 'Fresh Foods', 'freshfoods@gmail.com', 'fresh'),
(14, 'Ijebu Farms', 'ijebufarms@gmail.com', 'ijebu'),
(15, 'Ibaji Farms Ltd', 'ibaji@gmail.com', 'ibaji'),
(16, 'Seyifunmi Farms Ltd', 'seyifunmi@gmail.com', 'funmiseyi'),
(17, 'Seyifunmi Farms Ltd', 'seyifunmi@gmail.com', 'funmiseyi'),
(26, 'Gege Farms', '', ' '),
(27, 'jjj', 'jjjjjjjj', 'kkkkjjjjj '),
(28, 'James Ltd', 'femi@gmail.com', 'femi '),
(29, 'Bella Ayobami', 'bella@gmail.com', 'ayobami12 '),
(30, '                 ', '', '         ');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `orderid` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `Buyer` varchar(50) NOT NULL,
  `productid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`orderid`, `category`, `quantity`, `price`, `Buyer`, `productid`) VALUES
('5936b5d4aff42', 'Palm Oil', '1', '20000', 'John', '11'),
('5936b7abbd225', 'Cassava', '1', '2000', 'John', '9'),
('5936c42a18d08', 'Cassava', '1', '2000', 'John', '9'),
('5936c43118c64', 'Palm Oil', '2', '20000', 'John', '11');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(50) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `username`, `password`, `email`) VALUES
(9, 'admin', '123', 'fooddyadmin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', '123', 'fooddyadmin@gmail.com'),
(6, 'manager', '111', 'fooddymanager@gmail.com'),
(7, 'cook', '111', 'fooddycook@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `farmers`
--
ALTER TABLE `farmers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`orderid`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`,`email`),
  ADD UNIQUE KEY `username_2` (`username`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `farmers`
--
ALTER TABLE `farmers`
  MODIFY `id` int(50) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(50) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
